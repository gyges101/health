from django.shortcuts import render

# Create your views here.


def home(request):

    context = {
        
    }

    return render(request, 'home.html', context)


def hijama(request):

    context = {
        
    }

    return render(request, 'hijama.html', context)